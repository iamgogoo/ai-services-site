import { useRouter } from 'next/router';
import { useEffect } from 'react';

export default function CheckoutRedirect() {
  const router = useRouter();
  const { plan } = router.query;

  useEffect(() => {
    if (!plan) return;
    fetch(`/api/checkout/${plan}`, { method: 'POST' })
      .then(res => res.json())
      .then(data => {
        if (data.url) {
          window.location.href = data.url;
        } else {
          alert('Something went wrong');
        }
      });
  }, [plan]);

  return <p className="p-10 text-center">Redirecting to checkout...</p>;
}
