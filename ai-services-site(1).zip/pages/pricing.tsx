import { Button } from "@/components/ui/button";
import Link from "next/link";

export default function PricingPage() {
  return (
    <main className="min-h-screen bg-white py-20 px-6 text-gray-800">
      <section className="max-w-4xl mx-auto text-center">
        <h1 className="text-4xl font-bold mb-6">Choose Your Plan</h1>
        <p className="mb-10 text-lg">Upgrade for more credits and unlimited access to AI tools.</p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="border rounded-2xl p-6 shadow-sm">
            <h2 className="text-2xl font-semibold mb-2">Basic Tools</h2>
            <p className="mb-4 text-gray-600">$4.99 / month</p>
            <ul className="text-left list-disc list-inside mb-4 text-sm text-gray-700">
              <li>50 credits/month</li>
              <li>Access to writing assistant</li>
              <li>Email support</li>
            </ul>
            <Link href="/checkout/basic">
              <Button className="w-full text-lg">Subscribe Basic</Button>
            </Link>
          </div>

          <div className="border rounded-2xl p-6 shadow-sm">
            <h2 className="text-2xl font-semibold mb-2">Pro Tools</h2>
            <p className="mb-4 text-gray-600">$9.99 / month</p>
            <ul className="text-left list-disc list-inside mb-4 text-sm text-gray-700">
              <li>150 credits/month</li>
              <li>All AI tools access</li>
              <li>Priority support</li>
            </ul>
            <Link href="/checkout/pro">
              <Button className="w-full text-lg">Subscribe Pro</Button>
            </Link>
          </div>

          <div className="border rounded-2xl p-6 shadow-md bg-gray-50">
            <h2 className="text-2xl font-semibold mb-2">Yearly Pro</h2>
            <p className="mb-4 text-gray-600">$99 / year</p>
            <ul className="text-left list-disc list-inside mb-4 text-sm text-gray-700">
              <li>1800 credits/year</li>
              <li>All AI tools access</li>
              <li>2 months free</li>
              <li>Priority support</li>
            </ul>
            <Link href="/checkout/yearly">
              <Button className="w-full text-lg">Subscribe Yearly</Button>
            </Link>
          </div>
        </div>

        <p className="mt-10 text-sm text-gray-500">
          All payments are securely processed via Stripe. Supports Apple Pay & Google Pay.
        </p>
      </section>
    </main>
  );
}
