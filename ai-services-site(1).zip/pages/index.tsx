import { Button } from "@/components/ui/button";
import Link from "next/link";

export default function HomePage() {
  return (
    <main className="min-h-screen bg-gray-50 text-gray-800">
      <section className="max-w-5xl mx-auto py-20 px-6 text-center">
        <h1 className="text-5xl font-bold mb-6">
          Boost Your Online Work with Smart AI Tools
        </h1>
        <p className="text-lg mb-8">
          Explore the latest AI-powered services tailored for freelancers, marketers,
          and online entrepreneurs. Start with 10 free credits.
        </p>
        <div className="flex justify-center gap-4">
          <Link href="/signup">
            <Button className="text-lg px-6 py-3">Get Started</Button>
          </Link>
          <Link href="/pricing">
            <Button variant="outline" className="text-lg px-6 py-3">View Pricing</Button>
          </Link>
        </div>
      </section>
    </main>
  );
}
